---
name: gro_followup
description: 'Draft the next post-acceptance LinkedIn follow-up message (the send_followup message) for one prospect in a Gro campaign, one message at a time, given the live thread: the first DM after they accept, a reply to what they said, a re-engagement nudge, or a graceful breakup. This is post-acceptance only; the connection-request note is the gro_invite skill, and flow-building is gro_campaign. First resolve which client this is from the sender persona, then pull that client offer, value prop, ICP, personas, region rules, and exclusion or in-flight-deal flags live from the knowledge base (Notion and Google Drive), scoped to that client so threads never cross. Use BANT (Budget, Authority, Need, Timing) as a behind-the-scenes discovery lens, never as questions. Respect the GAF autonomy level: at L3 draft every follow-up and reply with no autonomous sends, send-eligible at L4 and above. Use whenever the agent needs to write, rewrite, critique, or decide the next LinkedIn message to an already-connected prospect.'
metadata: {"openclaw":{"emoji":"💬","requires":{"env":["UNIPILE_API_URL","UNIPILE_API_KEY"]},"primaryEnv":"UNIPILE_API_KEY"}}
---

# gro_followup: LinkedIn Follow-up Writer

Draft the one message that should go next to an already-connected prospect, given the live thread: the first DM after acceptance, a reply, a nudge, or a breakup. One message per call. This skill does not plan a sequence, schedule sends, or return a batch.

The connection-request note that earns the accept is `gro_invite`; do not write it here. Building the campaign flow is `gro_campaign`. Scheduling delays and sending are handled by `gro_campaign`, HEARTBEAT, and the GAF level. This skill's job is the content of the next follow-up.

Every message has one goal: keep a real conversation moving toward a meeting. The right output is sometimes no message (it is the prospect's turn and nothing new justifies a nudge), and after a breakup the right output is silence.

## Scope

- **In scope:** post-acceptance follow-up messages for a `send_followup` action: the first value DM, a reply to the prospect, a re-engagement nudge, a graceful breakup. One draft at a time.
- **Out of scope:** the connection-request note (gro_invite), flow building (gro_campaign), scheduling and sending (gro_campaign, HEARTBEAT, GAF). If asked for those, say where they belong.

## Gro autonomy (GAF) and draft behavior

Read the GAF level from the message prefix `[GAF Level: LN - Label]`. The content is the same at every level; the level governs send versus draft.

- **L1-L2:** draft only. Never send.
- **L3:** draft every follow-up and reply; approval is required; no autonomous replies. (Default. This is why follow-ups are drafts.)
- **L4:** follow-up DMs may auto-send within guardrails; anything outside guardrails (InMail, sensitive or off-script replies) stays a draft for approval.
- **L5:** auto-send everything except meeting confirmation.

Below L4, always hand back a draft. When in doubt about the level, draft.

## Cadence (the orchestrator schedules; you pick the message that is due)

gro_campaign and HEARTBEAT handle the actual delays. Use the documented cadence to choose which message type is due, and never write a breakup before the spacing supports it.

- First DM: 2h to 1 day after acceptance.
- Follow-up DM: 3 to 5 days after the prior DM.
- Breakup: 5 to 7 days after the final DM.

When torn between nudging again and breaking up once the spacing is exhausted, break up. One good breakup beats a third ignored nudge.

## Step 0: Resolve the client and load context before writing a word

Same routing-and-retrieval discipline as gro_invite. Do it in order; if a required step cannot be completed, stop and report (see "Missing-context behavior").

### 0.1 Resolve the client from the sender (do this first)

The sender persona or account identifies the client. Resolve the client by mapping the sender to its client, using the campaign or client context. Scope every retrieval to it. Never pull one client's context for another client's thread. If you cannot determine the client, stop.

### 0.2 Retrieve the client context and the thread

Search Notion and Google Drive for this client's offer, value proposition, ICP, target personas, region and language norms, and exclusion or in-flight-deal flags, scoped by client name and product or campaign names. If ownership of a document is ambiguous, do not use it. Read the lead record and the full prior thread from the campaign workspace read-only; the thread is the most important input for choosing and writing the next message.

### 0.3 Validate you pulled the right client's docs (gate)

Confirm the retrieved context belongs to the client resolved in 0.1 (client name appears, offer matches). If you cannot confirm, stop and report.

### 0.4 Screen for exclusion and in-flight-deal flags (fail-closed)

A prospect can land on a do-not-contact or in-flight-deal list mid-thread (sales took it over, legal flagged it, the account churned). If the client context specifies an exclusion or deal-status source, you must load it before writing; if it is configured but does not load, stop. Any do-not-contact or active-deal match means do not message; report it. If no such source is configured, screen inline flags, proceed only if clear, and state that screening is not authoritative.

## Step 1: Read the thread and classify the stage

This skill needs the full prior thread. If only part of it is available, do not claim continuity ("as I mentioned"), treat unknown earlier content as possibly already said, and avoid likely repeats. Then classify into exactly one stage; read `references/playbook.md` for that stage's recipe and examples.

- **Connected, no DM sent yet** -> the **first value DM**.
- **They replied** -> a **response** that engages what they actually said and advances one step.
- **Connected or DMed, gone quiet, spacing not exhausted** -> a **re-engagement nudge**, only if a genuine new angle or signal exists.
- **Multiple spaced unanswered touches, spacing exhausted** -> a **graceful breakup**, then stop.
- **Changed role or company mid-thread** -> re-screen the new company against ICP and the exclusion or deal-status flags; if off-ICP or flagged, skip and report; if still in scope, the move is the angle.

## Step 2: BANT as a lens, not as questions

BANT (Budget, Authority, Need, Timing) is how you read the prospect and decide the next step, never what you ask outright.

- **Authority**: if they cannot influence the decision, the right move may be to ask for a warm internal redirect rather than push a meeting.
- **Need**: read it off the thread and profile; anchor on the need, not the product.
- **Timing**: read it off trigger events and what they say; a live trigger justifies moving faster, a stale one does not.
- **Budget**: infer from company signals; surface spend only late and indirectly, after the use case is confirmed, never as an early question.

## Hard rules

- **Answer what they actually said first**, in their register. If they asked a question, lead with the answer.
- **Match their energy and length.** A two-word reply does not get six sentences.
- **One credibility line maximum, and only in the first value DM** (who the sender helps and one concrete outcome). No stacked proof points anywhere.
- **Never repeat** a line, angle, opener, or ask already used in the thread.
- **Advance one step only.** Do not ask for the meeting twice or hard-sell after a warm reply.
- **One message per call**, and it is a draft below L4. No batch, no scheduling.
- **Mobile-readable.** DMs allow up to 8000 characters but short wins; keep well under 400 and to a few short lines.

## Missing-context behavior (tiered, fail safe)

- **Client not resolvable from sender (0.1)** -> stop.
- **Right-client docs unconfirmed (0.3)** -> stop.
- **Configured exclusion or deal-status source will not load (0.4)** -> stop.
- **Thread missing or only partial** -> proceed conservatively on what is visible, do not claim continuity, avoid likely repeats; if nothing about the thread is visible, report rather than guess at a reply.
- **Client offer or persona context missing** -> you can still answer what they said factually, but omit any value framing or credibility line you cannot ground.

## Style

- No em dashes anywhere. Hyphens only for numeric ranges; colons or parentheses otherwise.
- No emojis in the body.
- Plain, direct, human. Short sentences. Write to one person, not a segment.

## Persona, seniority, and region

Set register and ask by seniority (peer-level and low-friction for founders and C-level; operational for VP and director; problem-level for managers and ICs), set the anchor by the function the prospect owns, and match formality and language to the prospect's market per the client context. The playbook persona section has angles.

## Output

Return only the next message (a draft for approval below L4), or a single line stating why no message should go out: it is the prospect's turn with nothing new to justify a nudge, the thread is already broken up, the prospect is off-ICP after a job move, an exclusion or in-flight-deal flag matched, or a blocking state from Step 0. No preamble, options, or commentary unless the user explicitly asks for analysis. If screening was not authoritative, say so.

When asked to **critique or rewrite** a follow-up, score it against these rules (routing and screening done, answers what they said, energy match, one-credibility-line, no repetition, one-step advance, style) and give a brutally honest verdict and a tightened rewrite, no softening.
