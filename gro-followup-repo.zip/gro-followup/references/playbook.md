# LinkedIn Follow-up Playbook

This skill drafts the next post-acceptance message for one prospect, one at a time, reading the live thread. The connection-request note is gro_invite and is not covered here.

Read the section for the stage classified in SKILL.md Step 1. Each gives the goal, what to do, what to avoid, and worked before/after examples. Fill every {placeholder} from live context; never ship a brace. Examples are illustrative; rewrite against the real prospect, sender, and resolved client context.

## Placeholder dictionary (get the perspective right)

| Placeholder | Means | Filled from | Common mistake |
| --- | --- | --- | --- |
| {first} | Prospect first name | Prospect profile | - |
| {prospect_company} | Prospect's company | Prospect profile or lead record | - |
| {prospect_function} | The buyer's team or function you help (infrastructure, RevOps, growth) | ICP plus profile | Filling the sender's own function |
| {prospect_segment} | Buyer segment from the ICP | Client ICP | Generic "companies" |
| {client_outcome} | One concrete result the client delivers | Client value prop | Stacking several outcomes |
| {trigger} | A live event anchored on | Profile, company news, or the thread | Inventing one |
| {topic} | Subject of a prior exchange | The thread | - |

The highest-frequency bug is mixing up function: you help the prospect's function, not the sender's.

## Contents

1. First value DM
2. Responding to a reply
3. Re-engagement nudge
4. Graceful breakup
5. Job change mid-thread
6. Persona and seniority angles
7. Signal-to-BANT mapping
8. Read-the-room checklist

---

## 1. First value DM (connected, nothing sent)

**Goal:** start a conversation, not book a meeting on touch one. Send 2h to 1 day after acceptance.

**Structure:** one line tying to why you connected or who they are; one plain credibility line (the only place it is allowed: who the sender helps and one concrete outcome); one light, specific question or soft offer that is easy to answer.

**Avoid:** dumping the full value prop, stacking proof points, a hard calendar ask, a wall of text.

**Before (pitch-slap):**
"Thanks for connecting! {prospect_company} should see our platform. We cut costs up to 60%. Do you have 30 minutes this week for a demo?"

**After (conversation starter):**
"Thanks for connecting, {first}. We help {prospect_function} teams at {prospect_segment} {client_outcome}. Given {their inferred priority}, curious how you handle {specific problem} today. Worth comparing notes?"

---

## 2. Responding to a reply

**Goal:** keep it alive and advance exactly one step. The reply is the highest-value moment in the thread.

**Do:** answer what they actually said first, in their register. If they asked a question, lead with the answer. Match length and energy. Advance one step only.

**Avoid:** ignoring their words to push your agenda, a sudden hard sell after a warm reply, multi-paragraph replies to one-liners, asking for the meeting twice.

**Reply type -> move:**
- Positive or curious -> answer, then propose the single lightest next step (short call or a specific resource).
- Question -> answer plainly, then one short forward step.
- Objection or "not now" -> acknowledge without arguing, leave a door open, do not push. Often the right move is a brief gracious reply and waiting.
- Referral -> thank them, ask for the warm intro or the name, do not over-ask.

**Before (steamrolls a warm reply):**
"Great! Here is my calendar, grab any 30-minute slot and I will walk you through the full platform and pricing."

**After (matches energy, one step):**
"Appreciate that, {first}. Sounds like {their point} is the live issue. Happy to show how {peer or segment} handled it in 15 minutes, no deck. Early next week, or is later better?"

---

## 3. Re-engagement nudge (gone quiet, spacing not exhausted)

**Goal:** revive a silent thread, only when there is a real new reason. A nudge with nothing new is nagging; if there is no new angle, do not nudge. Space 3 to 5 days after the prior DM.

**Do:** lead with the new thing (a fresh trigger, a relevant launch, a piece of value that did not exist last time). Keep it short and pressure-free. Reference the prior thread lightly.

**Avoid:** "just bumping this", "did you see my last message", guilt, fake scarcity.

**Before (empty bump):**
"Hi {first}, just following up on my message below. Any thoughts?"

**After (new angle):**
"{first}, saw {trigger}. Reminded me of our earlier thread on {topic}. If useful, {short value or resource}. No pressure either way."

---

## 4. Graceful breakup (cold, spacing exhausted)

**Goal:** close the loop cleanly after multiple spaced, unanswered touches. A good breakup protects the relationship and often pulls the reply the nudges could not. Send 5 to 7 days after the final DM.

**When:** default to a breakup rather than a third unanswered nudge once spacing is exhausted. After the breakup, stop unless they re-engage.

**Do:** short, warm, guilt-free, genuinely easy to say no to, door left open. One message, then silence.

**Avoid:** passive-aggression, "I guess you are not interested", a final hard pitch, more than one breakup.

**Example:**
"{first}, I will leave it here so I am not cluttering your inbox. If {problem_area} ever moves up the list, my door is open. Wishing you and {prospect_company} a strong quarter."

---

## 5. Job change mid-thread

A prospect who moved roles or companies is a distinct, common case.

**Re-screen first.** A move can put them at a non-ICP company or onto the exclusion or in-flight-deal list. Re-run Step 0 screening against the new company. If off-ICP or flagged, skip and report.

**If still in scope, the move is the opener.** A new role, especially in the first 90 days, resets priorities and is a strong, genuine angle. Acknowledge it plainly and tie it to the relevant need, without rehashing the old thread as if nothing changed.

**Example (new role, still in scope):**
"{first}, saw you have taken on {new_role} at {prospect_company}, congrats. New seats usually mean rethinking {problem_area} early. Happy to share what {peer or segment} did in their first quarter if useful."

---

## 6. Persona and seniority angles

Read the profile and adapt. Anchor on the outcome that person owns.

- **Founder / CEO / C-level:** peer-to-peer, outcome and strategy framing, very low friction. Soft ask, never a long demo pitch. Respect their time in word count.
- **VP / Director:** team-outcome and operational-leverage framing. They care about hitting a number and de-risking a bet. Concrete, credible, concise.
- **Manager / Lead:** problem-level and workflow framing. They feel the day-to-day pain; anchor there and be specific.
- **Practitioner / IC:** most concrete, tool-and-task level. Often a router to the buyer; a warm internal redirect can be the real win.

Cross-cut by function: anchor on what that function is measured on (revenue for sales, efficiency and risk for ops, performance and cost for engineering, pipeline for marketing), pulled from the client context, not guessed.

---

## 7. Signal-to-BANT mapping

Read BANT off real signals instead of asking. This is discovery, not message content.

- **Authority:** title, scope language, who they report to, decision phrasing. Weak authority means consider a redirect ask.
- **Need:** what they say in-thread, posts about a problem, stated priorities, vendor or tech mentions, a pain the role owns.
- **Timing:** new role, funding, reorg, launch, expansion, budget-cycle signals. A live trigger justifies moving faster.
- **Budget:** company size, funding stage, headcount, market cap. Infer quietly; surface spend only late and indirectly after the use case is confirmed.

---

## 8. Read-the-room checklist

Run this against every drafted message before returning it:

1. Client resolved from the sender and context scoped to it; exclusion and in-flight-deal screening done (or its non-authoritative status noted)?
2. Right stage (first DM vs reply vs nudge vs breakup vs job-change), and does the cadence support it (not a premature breakup)?
3. Does it answer or build on the last actual thing in the thread, not a script?
4. Repeats any line, angle, or ask already in the thread? (If yes, rewrite.)
5. Matches their energy and length?
6. One credibility line at most, and only in the first DM? BANT used as a lens, no qualification questions in the text?
7. Advances exactly one step, no double meeting-asks?
8. Style: no em dashes, no emojis, no throat-clearing, no fake urgency?
9. Every placeholder filled from live context with the right perspective (you help the prospect's function, not the sender's)?
