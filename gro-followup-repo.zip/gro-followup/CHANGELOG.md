# Changelog

All notable changes to this skill are documented here. Format based on Keep a Changelog.

## [1.0.0] - 2026-06-30

### Added
- Initial release of `gro_followup`, the post-acceptance LinkedIn follow-up writer for Gro V3.
- One message per call, read off the live thread: first value DM, reply, re-engagement nudge, graceful breakup, and job-change handling.
- Client resolution from the sender persona, with all knowledge-base retrieval scoped to the resolved client (Notion and Google Drive).
- Fail-closed exclusion and in-flight-deal screening for mid-thread status changes.
- BANT used as a behind-the-scenes discovery lens, never as questions.
- GAF-aware behavior: draft every follow-up and reply at L3, send-eligible within guardrails at L4 and above.
- Cadence guidance aligned to the documented timings (first DM 2h-1d, DM to DM 3-5d, breakup 5-7d).
- `references/playbook.md` with stage recipes, persona and seniority angles, and worked examples.
